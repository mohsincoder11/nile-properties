<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectEntryAppendData extends Model
{
    use HasFactory;
    protected $fillable = [
        'project_entry_id',
        'plot_no',
        'plot_width',
        'plot_length',
        'area_sqrft',
        'area_sqrmt',
        'east',
        'west',
        'south',
        'north',
        'rate',
    ];
}