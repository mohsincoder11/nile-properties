{{-- @json($emp) --}}

@foreach ($emp as $emps)
{{$emps->account_holder_name}}

@endforeach
