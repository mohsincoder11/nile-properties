@extends('webscite.layout')
@section('content')
<section class="contact-section" style="padding-top: 66px;">
    <div class="auto-container">
        <div class="row">
            <div class="text-column col-lg-6 col-md-12 col-sm-12">
                <img src="{{asset ('public/images1/thankyou.png') }}">
            </div>

            <div class="form-column col-lg-6 col-md-12 col-sm-12">
                <h1 align="center" style="margin-bottom: 5px; margin-top:10%; font-size: 74px;"><b style="color:black;"
                        class="spectral font-size-131"> Thank you!</b></h1>
                <p style="font-size: 22px; padding-left:18%;">
                    Your message has been received. We appreciate your time and will get back to you as soon as
                    possible. </p>

                <div class="contact-form">


                    <div class="col-lg-12 col-md-12 col-sm-12" align="center">

                    </div>
                </div>
            </div>


        </div>
    </div>
</section>

@stop
@section('js')


@stop