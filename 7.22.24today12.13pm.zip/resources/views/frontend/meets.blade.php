@extends('frontend.layouts.header')

@section('main-container')


<!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">
        <div class="row">
            <div class="col-md-8 mx-auto" style="margin-left: 23%;">
                <div class="card">
                    <div class="card-body p-4">
                        <h5 class="card-title">Meets</h5>
                        <hr />
                        @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        @if(session('success1'))
                        <div class="alert alert-success">
                            {{ session('success1') }}
                        </div>
                        @endif
                        <div class="form-body mt-4">
                            <div class="page-content">

                                <div class="col-md-12 mx-auto">

                                    <form action="{{route('meet.store')}}" method="post">
                                        @csrf

                                        <div class="row">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-4">
                                                <div class="mb-3">
                                                    <label for="inputProductTitle" class="form-label">
                                                        Title</label>
                                                    <input type="text" class="form-control" id="inputProductTitle"
                                                        placeholder="" name="title" value="{{ old('title') }}" required>
                                                    @if ($errors->has('title'))
                                                    <span class="text-danger">{{ $errors->first('title') }}</span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="mb-3">
                                                    <label for="inputProductTitle" class="form-label">
                                                        Upload URL</label>
                                                    <input type="text" class="form-control" id="inputProductTitle"
                                                        placeholder="" name="url" value="{{ old('url') }}" required>
                                                    @if ($errors->has('url'))
                                                    <span class="text-danger">{{ $errors->first('url') }}</span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="mb-3">
                                                    <div style="margin-top:10%; padding-left:0px; padding-top:19px;">
                                                        <button type="submit" class="btn btn-primary">Submit</button>

                                                    </div>
                                                </div>

                                            </div>



                                        </div>
                                    </form>

                                </div>

                            </div>
                        </div>
                        <!--end row-->

                    </div>
                </div>
                <script>
                    $('#main_description').summernote({
								placeholder: 'Write  Here',
								tabsize: 2,
								height: 120,
								toolbar: [
									['style', ['style']],
									['font', ['bold', 'underline', 'clear']],
									['color', ['color']],
									['para', ['ul', 'ol', 'paragraph']],
									['table', ['table']],
									['insert', ['link', 'picture', 'video']],
									['view', ['fullscreen', 'codeview', 'help']]
								]
							});
                </script>
            </div>
        </div>

        <div class="col-md-9">

            <!-- Modal -->
            <div class="modal fade" id="exampleExtraLargeModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="page-content">
                            <div class="row">
                                <div class="col-md-9 mx-auto">
                                    <div class="card">
                                        <div class="card-body p-4">


                                            <h5 class="card-title">Add Question</h5>
                                            <hr />
                                            <div class="form-body mt-4">
                                                <div class="page-content">
                                                    <div class="border border-3 p-4 rounded">
                                                        <div class="col-md-12 mx-auto">

                                                            <div class="row">

                                                                <div class="col-md-4">
                                                                    <div class="mb-3">
                                                                        <label for="inputProductDescription"
                                                                            class="form-label">Image <span
                                                                                style="color:red;">(370px*303px)</span></label>
                                                                        <input id="" type="file"
                                                                            accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf"
                                                                            multiple>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="mb-3">
                                                                        <label for="inputProductTitle"
                                                                            class="form-label">
                                                                            Title</label>
                                                                        <input type="email" class="form-control"
                                                                            id="inputProductTitle"
                                                                            placeholder="Enter Story title">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="mb-3">
                                                                        <label for="inputProductTitle"
                                                                            class="form-label">
                                                                            Question Text</label>
                                                                        <input type="email" class="form-control"
                                                                            id="inputProductTitle"
                                                                            placeholder="Enter Story title">
                                                                    </div>
                                                                </div>





                                                            </div>

                                                        </div>

                                                        <div class="col-md-12 mx-auto">


                                                            <div class="col-md-12 mx-auto">
                                                                <div class="row">
                                                                    <div class="col-md-2">
                                                                        <div class="mb-3">
                                                                            <label for="inputProductTitle"
                                                                                class="form-label">
                                                                                Option 1</label>
                                                                            <input type="email" class="form-control"
                                                                                id="inputProductTitle" placeholder="">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-2">
                                                                        <div class="mb-3">
                                                                            <label for="inputProductTitle"
                                                                                class="form-label">
                                                                                Option 2</label>
                                                                            <input type="email" class="form-control"
                                                                                id="inputProductTitle" placeholder="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <div class="mb-3">
                                                                            <label for="inputProductTitle"
                                                                                class="form-label">
                                                                                Option 3</label>
                                                                            <input type="email" class="form-control"
                                                                                id="inputProductTitle" placeholder="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <div class="mb-3">
                                                                            <label for="inputProductTitle"
                                                                                class="form-label">
                                                                                Option 4</label>
                                                                            <input type="email" class="form-control"
                                                                                id="inputProductTitle" placeholder="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <div class="mb-3">
                                                                            <label for="inputProductTitle"
                                                                                class="form-label">
                                                                                Right Option</label>
                                                                            <input type="email" class="form-control"
                                                                                id="inputProductTitle" placeholder="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-2">
                                                                        <div class="mb-3">
                                                                            <label for="inputProductDescription"
                                                                                class="form-label">Short
                                                                                Description</label>
                                                                            <textarea class="form-control"
                                                                                id="inputProductDescription"
                                                                                rows="1"></textarea>
                                                                        </div>
                                                                    </div>





                                                                </div>





                                                                <div class="col-md-12" align="center">
                                                                    <div
                                                                        style="margin-top:2px; padding-left:0px; padding-top:10px;">
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Add</button>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <script>
                                        $('#main_description').summernote({
													placeholder: 'Write  Here',
													tabsize: 2,
													height: 120,
													toolbar: [
														['style', ['style']],
														['font', ['bold', 'underline', 'clear']],
														['color', ['color']],
														['para', ['ul', 'ol', 'paragraph']],
														['table', ['table']],
														['insert', ['link', 'picture', 'video']],
														['view', ['fullscreen', 'codeview', 'help']]
													]
												});
                                    </script>
                                </div>
                            </div>

                            <div class="col">
                                <!-- Modal -->
                                <div class="modal fade" id="exampleExtraLargeModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Modal title</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">Contrary to popular belief, Lorem Ipsum is
                                                not simply random text. It has roots in a piece of classical
                                                Latin literature from 45 BC, making it over 2000 years old.
                                                Richard McClintock, a Latin professor at Hampden-Sydney College
                                                in Virginia, looked up one of the more obscure Latin words,
                                                consectetur.</div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-primary">Save
                                                    changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>




        <!--end page wrapper -->
        <!--start overlay-->
        <div class="overlay toggle-icon"></div>
        <!--end overlay-->
        <!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i
                class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->

    </div>
    <!--end wrapper-->
    <div class="col-md-8" style="margin-left: 18%;  margin-top: -40px;">

        <div class="card-body">
            <div class="tab-content py-3">
                <div class="tab-pane fade show active" id="primaryhome" role="tabpanel">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Sr. No</th>

                                            <th>Title</th>


                                            <th>URL</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        @foreach($Meet as $Meet)
                                        <tr>

                                            <td>{{$loop->index+1}}</td>

                                            <td>{{$Meet->title}}</td>
                                            <td>{{ Str::limit($Meet->url, 50) }}</td>
                                            <td>
                                                <a href="#"
                                                    onclick="openCustomModal('{{route('meet.destroy', $Meet->id)}}')">
                                                    <button type="button" class="btn1 btn-outline-danger"
                                                        title="Delete"><i class='bx bx-trash me-0'></i>
                                                </a>
                                            </td>

                                        </tr>

                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                @endsection